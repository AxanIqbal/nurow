package com.nurowai.nurow

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
