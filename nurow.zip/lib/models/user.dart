import 'dart:convert';

List<User> userFromJson(String str) =>
    List<User>.from(json.decode(str).map((x) => User.fromJson(x)));

String userToJson(List<User> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class User {
  User({
    required this.creationTime,
    required this.email,
    required this.lastSignInTime,
    required this.lastLogOutTime,
    required this.userName,
  });

  String creationTime;
  String email;
  List<String> lastSignInTime;
  List<String> lastLogOutTime;
  String userName;

  factory User.fromJson(Map<String, dynamic> json) => User(
        creationTime: json["creationTime"],
        email: json["email"],
        lastSignInTime: List<String>.from(json["lastSignInTime"].map((x) => x)),
        lastLogOutTime: List<String>.from(json["lastLogOutTime"].map((x) => x)),
        userName: json["userName"],
      );

  Map<String, dynamic> toJson() => {
        "creationTime": creationTime,
        "email": email,
        "lastSignInTime": List<dynamic>.from(lastSignInTime.map((x) => x)),
        "lastLogOutTime": List<dynamic>.from(lastLogOutTime.map((x) => x)),
        "userName": userName,
      };
}
