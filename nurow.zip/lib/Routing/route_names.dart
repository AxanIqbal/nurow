const String landingRoute = "landing";

const String loginRoute = "login";

const String contactRoute = "contact";

const String analysisPage = "selectImage";

const String patientDetailsPage = "patientsSelect";

const String userManagementPage = "userManagement";